"""
Monkeypatching Pandas Dataframe to include `to_sql_bulk` method
that uploads dataframe to mssql server using mssql-tools `bcp`.
Requires mssql-tools to be installed on system and in (USER) PATH
environment.
"""

from functools import wraps
from pandas import DataFrame
from pandas.io.sql import SQLTable, pandasSQL_builder

import subprocess
import tempfile
import binascii
import re
import os
import urllib
import shutil
import sqlalchemy

import logging

logger = logging.getLogger("to_sql_bulk")

def monkeypatch_method(cls):
    @wraps(cls)
    def decorator(func):
        setattr(cls, func.__name__, func)
        return func
    return decorator

def temp_opener(name, flag, mode=0o777):
    """A little hack that opens a file with the correct
       file system flags so that any other windows process
       is allowed to open it simultaneously"""
    return os.open(name, flag | os.O_TEMPORARY, mode)

@monkeypatch_method(DataFrame)
def to_sql_bulk(self, table, schema, database, driver, server,
               if_exists="append", packet_size = 16384,
               batch_size = 50000, index=False, print_debug = False):
    """Writes Dataframe to Microsoft SQL server via bcp utility."""

    if print_debug:
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        logger.addHandler(ch)
        
    if shutil.which('bcp') is None:
        raise EnvironmentError("Could not find a program called 'bcp' in your PATH variable. " +
                               "Please install Microsoft's Command Line Utilities for SQL server " + 
                               "first or manually add the path to the bcp executable to your user PATH.")
        
    conn_str = f'Driver={{{driver}}};Server={server};Database={database};Trusted_Connection=Yes;'
    quoted_conn_str = urllib.parse.quote_plus(conn_str)
    logger.debug(f"Connection string: {conn_str}")
    
    engine = sqlalchemy.create_engine("mssql+pyodbc:///?odbc_connect={}".format(quoted_conn_str))
    
    table_obj = SQLTable(table, pandasSQL_builder(engine), self, if_exists=if_exists, index=index, schema=schema)
    table_schema = table_obj.sql_schema()

    if table_obj.exists():
        logger.debug(f"Table {table} already exists")

        if if_exists == 'fail':
            raise ValueError(f"Table {table} exists")
        elif if_exists == 'append':
            queue = []
        elif if_exists == 'replace':
            logger.debug("Dropping table")

            queue = [f'DROP TABLE {table}', table_schema]
        else:
            raise ValueError("Bad option for `if_exists`")
    else:
        logger.debug(f"Table {table} does not exist. Creating.")
        logger.debug(table_schema)

        queue = [table_schema]

    with engine.begin() as con:
        for stmt in queue:
            con.execute(stmt)

    logger.info(f"Writing table {table} to {server}:{database} using trusted connection")

    fp = tempfile.NamedTemporaryFile(mode='w', delete=False)
    try:
        line_terminator = '\n'
        field_separator = '\t'
        line_terminator_esc = r'\n'
        field_separator_esc = r'\t'
        

        csv_params = {'header':False,
                      'index':index,
                      'line_terminator':line_terminator,
                      'sep':field_separator,
                      'encoding': 'utf-8'}

        self.to_csv(fp, **csv_params)
        fp.flush()
        fp.close()


        bcp_cmd = f'bcp {(schema + ".") if schema else ""}{table} in {fp.name} -S {server} -d {database} -T -t "{field_separator_esc}"  -r "{line_terminator_esc}" -c -a {packet_size} -b {batch_size}'
        
        logger.info(f"Running BCP command: {bcp_cmd}")

        sproc = subprocess.run(bcp_cmd, shell=True, stdout=subprocess.PIPE)

        logger.debug(f"BCP exit code: {sproc.returncode}")

        rows_pattern = re.compile("(\d+) rows copied.")
        bcp_copied_rows = int(rows_pattern.findall(sproc.stdout.decode('utf8'))[0])

        if len(self) != bcp_copied_rows:
            logger.error("DataFrame row number mismatch by BCP")
            logger.error(sproc.stdout)

        if sproc.returncode > 0:
            logger.error("BCP error")
            logger.error(sproc.stdout)
    finally:
        os.remove(fp.name)