#!/usr/bin/env python

import sys
try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

if sys.version_info < (3, 5):
    raise NotImplementedError("Sorry, you need at least Python 3.5+ to use BulkUpload utility.")

setup(name='bulkupload',
      version='1.0.4',
      description='Fast and simple module that adds SQL server bulk upload functionality to Pandas dataframes',
      long_description='Fast and simple module that adds SQL server bulk upload functionality to Pandas dataframes by monkey patching',
      author="Laurens Janssen",
      author_email='laurens.janssen@nnip.com',
      py_modules=['bulkupload'],
      scripts=['bulkupload.py'],
      install_requires=['pandas', 'sqlalchemy'],
      classifiers=['Intended Audience :: Developers',
                   'License :: OSI Approved :: MIT License',
                   'Programming Language :: Python :: 3.5',
                   'Programming Language :: Python :: 3.6',
                   'Programming Language :: Python :: 3.7',
                   ],
      )